package log4j.com;

import java.io.File;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class FileAppender 
{
	static Logger logger=Logger.getLogger(FileAppender.class);
    public static void main(String[] args) 
	{
	  PropertyConfigurator.configure(System.getProperty("user.dir")+File.separator+"log4j.properties");
       logger.debug("this is a debug log message");
       logger.info("this is a information log message");
       logger.warn("this is a warning log message");
	}

}
