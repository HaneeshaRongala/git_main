package com.vehicle;

public interface vehicle_interface
{
	abstract void start();
	abstract void sensors();
	abstract void stop();
	abstract void enginespeed();
}
